package com.example.seminarska_rabota;

import com.example.seminarska_rabota.Apteka_Aloe.vraboteni;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.junit.runner.jupiter.api.RunWith;

import javax.lang.model.element.Name;

@RunWith(SpringRunner.class)
@SpringBootTest
class SeminarskaRabotaApplicationTests {

    @Test
    public void contextLoads() {

    }

}
