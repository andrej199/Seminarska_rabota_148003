package com.example.seminarska_rabota.Apteka_Aloe;

import org.springframework.data.repository.CrudRepository;

import java.util.List;

@Repository
public interface vraboteniRepository extends CrudRepository <vraboteni, Long>{
List<vraboteni> findByName(string ime);
}
