package com.example.seminarska_rabota.Apteka_Aloe;

public @interface Repository {
}
