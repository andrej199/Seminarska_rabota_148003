package com.example.seminarska_rabota.Apteka_Aloe;


import javax.lang.model.element.Name;
import javax.validation.constraints.NotBlank;
import javax.persistence.*;

@Entity
@Table(name = "vraboteni")
public class vraboteni {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotBlank(message = "Name is mandatory")
    @Column(name = "ime_Id" ,insertable = false)
    private String ime;

    @Column(name = "prezime_id" , insertable = false)
    private String prezime;

    @Column(name = "Telefon_id", insertable = false)
    private long Telefon;

    @Column(name = "emanl_id", insertable = false)
    private String emanl;

    @Column(name = "faksimil_id", insertable = false)
    private long faksimil;

    public vraboteni() {}

    @ManyToOne
    @JoinColumn(name = "ime_id",name = "ime_id", name = "prezime_id", name = "Telefon_id",name = "emanl_id", name = "faksimil_id", nullable = false)
    private Name ime;

    @ManyToMany
    @JoinTable( name = "vraboteni",
            joinColumns = @JoinColumn(name = "ime_id", name = "prezime_id", name = "Telefon_id",name = "emanl_id", name = "faksimil_id")
            )

    @java.lang.Override
    public java.lang.String toString() {
        return "vraboteni{}";
    }

    public vraboteni(String ime, String prezime, String emanl) {
        this.ime = ime;
        this.prezime = prezime;
        this.emanl = emanl;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public long getTelefon() {
        return Telefon;
    }

    public void setTelefon(long telefon) {
        Telefon = telefon;
    }

    public String getEmanl() {
        return emanl;
    }

    public void setEmanl(String emanl) {
        this.emanl = emanl;
    }

    public long getFaksimil() {
        return faksimil;
    }

    public void setFaksimil(long faksimil) {
        this.faksimil = faksimil;
    }


}
