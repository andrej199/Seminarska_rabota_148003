package com.example.seminarska_rabota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;

@Controller
@SpringBootApplication
public class SeminarskaRabotaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SeminarskaRabotaApplication.class, args);
    }

}
