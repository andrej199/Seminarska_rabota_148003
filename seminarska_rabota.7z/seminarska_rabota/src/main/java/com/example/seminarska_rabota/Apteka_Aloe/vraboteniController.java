package com.example.seminarska_rabota.Apteka_Aloe;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;
import net.javaguides.springboot.tutorial.entity.vraboteni;
import net.javaguides.springboot.tutorial.repository.vraboteniRepository;

@Controller
@RequestMapping("/vraboteni")
public class vraboteniController {

    @Autowired
    private vraboteniRepository vraboteniRepository;

    @GetMapping("showForm")
    public String showVraboteniFrom(){
        return "add-vraboteni";
    }

    @GetMapping("list")
    public String vraboteni(Model model){
        model.addAllAttributes(vraboteni, this.vraboteniRepository.findAll());
        return "index";

    }

    @PostMapping("add")
    public String addVraboteni(@Valid Vraboteni vraboteni, BindingResult result, Model model){
        if(result.hasErrors()){
            return "add-vraboteni";
        }
        this.vraboteniRepository.save(vraboteni);
        return "redirect:list0";
    }

    @GetMapping("edit/{telefon}")
    public String showUpdateFrom(@PathVariable("telefon"), long telefon, Model model){
        Vraboteni vraboteni = this.vraboteniRepository.findById("telefon").orElseThrow(()-> new IllegalArgumentException("Invalid vraboteni telefon : " + telefon));

        model.addAllAttributes("vraboteni", vraboteni);
        return "update-vraboteni";

    }

    @GetMapping("update/{telefon}")
    public String updateVraboteni(@PathVariable("id")long telefon,@Valid Vraboteni vraboteni, BindingResult result, Model model){
    if (result.hasErrors()){
        vraboteni.setId(telefon);
        return "update-vraboteni";
    }

    vraboteniRepository.save(vraboteni);
    model.addAllAttributes("vraboteni", this.vraboteniRepository.findAll());
    return "index";

    }

    @DeleteMapping("delete/{telefon}")
    public <Vraboteni> String deleteStudent(@PathVariable ("telefon"), long telefon, Model model){
        Vraboteni vraboteni = this.vraboteniRepository.findById("telefon").orElseThrow(()-> new IllegalArgumentException("Invalid vraboteni telefon : " + telefon));

        this.vraboteniRepository.delete(vraboteni);
        model.addAllAttributes("vraboteni", this.vraboteniRepository.findAll());
        return "index";


    }

    private class Vraboteni {
    }
}
