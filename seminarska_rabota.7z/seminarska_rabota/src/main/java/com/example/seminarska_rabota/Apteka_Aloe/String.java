package com.example.seminarska_rabota.Apteka_Aloe;

public class String {
}
